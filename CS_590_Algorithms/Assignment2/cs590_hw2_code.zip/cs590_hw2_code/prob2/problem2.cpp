#include<iostream>
#include <stack>
#include<climits>
using namespace std;

class Queue{
private:
    stack<int> stack1, stack2;
public:
    void EnQueue(int data){
        
    }

    int DeQueue(){
        return 0; //replace with value that needs to be returned by the DeQueue operation
    }

};

int main(){
    Queue q;
    for(int i=0; i<10; i++)
        q.EnQueue(i);
    cout<<q.DeQueue()<<'\n';
    cout<<q.DeQueue()<<'\n';
    for(int i=10; i<20; i++){
        q.EnQueue(i);
    }
    cout<<q.DeQueue()<<" ";
    cout<<q.DeQueue()<<'\n';

    return 0;
}