#include <iostream>
#include "LinkedList.h"

using namespace std;

// First implementation; uses additional data structure
void removeDupl_1(Node* head)
{
    
}


// This implementation uses no additional data structure 
void removeDupl_2(Node* head)
{
    
}


int main()
{
    LinkedList* myList = new LinkedList();
    myList->insert(5);
    myList->insert(7);
    myList->insert(12);
    myList->insert(7);
    myList->insert(16);
    myList->insert(16);
    myList->insert(25);
    myList->insert(11);
    myList->insert(5);

    cout << "The original list is: ";
    myList->display();

    //Use removeDupl_2 to run that implementation
    removeDupl_1(myList->head);

    cout << "The list with duplicated removed is: ";
    myList->display();
    delete myList;

    return 0;
}