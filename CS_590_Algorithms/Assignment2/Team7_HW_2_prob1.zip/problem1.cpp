#include <iostream>
#include "LinkedList.h"
#include <set>

using namespace std;

// First implementation; uses additional data structure
void removeDupl_1(Node* head)
{
    //Using 'Set' as STL container
    set<int> set1;
    set<int>::iterator itr;
    Node* current = head;

    //Inserting list elements into set, which will not allow duplicates
    while(current != nullptr)
    {
        set1.insert(current->data);
        current = current->next;
    }

    current = head;
    Node* prev;

    //Copying unique elements back to list
    for (itr = set1.begin(); itr !=set1.end(); ++itr) 
    {
        current->data = *itr;
        prev = current;
        current = current->next;
    } 

    //Assigning new end of list
    prev->next = nullptr;

    //Deleting remaining dereferenced list elements from memory
    Node* next;
    while(current != nullptr)
    {
        next = current->next;
        delete current;
        current = next;
    }
}

// This implementation uses no additional data structure 
void removeDupl_2(Node* head)
{
    Node* templ = head;
    
    while(templ != nullptr)
    {
        int tempdata = templ->data;
        Node* prev = templ;
        Node* x = templ->next;

        while (x != nullptr)
        {
            Node* next = x->next;
            if(x->data == tempdata)
            {   
                prev->next = next;
                delete x;
            }
            else
            {
                prev = prev->next;
            }
            x = next;
        }
        templ = templ->next;
    }
}


int main()
{
    LinkedList* myList = new LinkedList();
    myList->insert(5);
    myList->insert(7);
    myList->insert(12);
    myList->insert(7);
    myList->insert(16);
    myList->insert(16);
    myList->insert(25);
    myList->insert(11);
    myList->insert(5);
    cout << "The original list is: ";
    myList->display();

    //Taking user choice of algorithm
    if(myList->head != nullptr)
    {
        char c,y;

        y:
        cout << "\nWhich algorithm do you want to choose for removing duplication ? \n1. for algorithm 1\n2. for algorithm 2" << endl;
        cin >> c;
        if(c == '1') removeDupl_1(myList->head);
        else if( c == '2') removeDupl_2(myList->head);
        else 
        {
            cout << "Please enter valid choice!\n";
            goto y;
        }
    }

    cout << "The list with duplicated removed is: ";
    myList->display();
    delete myList;
    return 0;
}