#include<iostream>
#include <stack>
#include<climits>
using namespace std;

class Queue{
private:
    stack<int> stack1, stack2;
public:
    void EnQueue(int data){

        cout << "\nPeforming EnQueue Operation " << endl;

        while(stack2.size() != 0)
        {
            stack1.push(stack2.top());
            stack2.pop();
        }

        stack1.push(data);
        cout << "After Enqueuing " << data << " , Queue is : ";
        display();
    }

    int DeQueue(){

        cout << "\nPeforming DeQueue Operation " << endl;

        while(stack1.size() != 0)
        {
            stack2.push(stack1.top());
            stack1.pop();
        }

        //Error checking: Underflow
        if(stack2.empty() == true)
        {
            cout << "Error : Trying to Perform DeQueue operation on an empty Queue!" << endl;
            return 0;
        }
        else
        {
            int poped = stack2.top();
            stack2.pop();
            cout << "DeQueued Element : " << poped << endl;
            cout << "After Dequeuing , Queue is : ";
            display();
            return poped; //replace with value that needs to be returned by the DeQueue operation
        }
    }

    //Display elements of queue
    void display(){

        if(stack1.size() == 0 && stack2.size() == 0)
            cout << "Empty Queue" << endl;
        else if(stack2.size() == 0)
        {
            stack<int> temp = stack1;
            int len = temp.size(), j = 0, arr[len];

            while(temp.size() != 0)
            {
                arr[j] = temp.top(); 
                temp.pop();
                j++;
            }

            for(;len>0;len--)
                cout << arr[len-1] << " ";

            cout << endl;
        }
        else
        {
            stack<int> temp = stack2;

            while(temp.size() != 0)
            {
                cout << temp.top() << " ";
                temp.pop();
            }

            cout << endl;
        }
    }
};

int main(){
    Queue q;
    cout << "Initially Queue is Empty!" << endl;

    //Test case
    for(int i=0; i<4; i++)
        q.EnQueue(i);

    q.DeQueue();
    q.EnQueue(45);
    q.DeQueue();
    q.DeQueue();
    q.DeQueue();
    q.DeQueue();
    q.DeQueue();
    
    return 0;
}