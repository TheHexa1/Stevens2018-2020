#ifndef __RB_TREE_H__
#define __RB_TREE_H__

enum rb_tree_color 
{
  RB_RED,
  RB_BLACK
};

struct rb_tree_node 
{
  int		key;
  int		color;
  rb_tree_node*	left;
  rb_tree_node*	right;
  rb_tree_node*	p;
};

class rb_tree
{ 
  protected:
    rb_tree_node*	T_nil;
    rb_tree_node*	T_root;

    int count_duplicates = 0, 
        count_case_1 = 0, 
        count_case_2 = 0, 
        count_case_3 = 0,
        count_left_rotate = 0,
        count_right_rotate = 0,
        count_black_nodes = 0;

    int* array_of_keys;
    int new_array_length;
    int height=0;

  public:
    rb_tree();
    ~rb_tree();

    void insert(int*, int);
    void insert(int);

    rb_tree_node* tree_search(rb_tree_node*, int);

    int get_black_node_counts()
      { return find_number_of_black_nodes(T_root); }    

    int inorder_output()
      { return inorder_output(T_root, 1); }
    void output()
      { output(T_root, 1); }
      
    void setArrayOfkeys(int*& a)
      { array_of_keys = a; }  

    void setArrayLength(int n)
      { new_array_length = n; } 

    int getArrayLength()
      { return new_array_length; }    

  protected:
    void insert(rb_tree_node*);
    void insert_fixup(rb_tree_node*&);

    void remove_all(rb_tree_node*);

    void left_rotate(rb_tree_node*);
    void right_rotate(rb_tree_node*);

    int inorder_output(rb_tree_node*, int);
    void output(rb_tree_node*, int);

    int find_number_of_black_nodes(rb_tree_node*);
};


#endif
