#include <cstdio>
#include <cstdlib>

#include "sort.h"
#include "bs_tree.h"
#include "rb_tree.h"
#include "timer.h"
#include "random_generator.h"

double getSum(int* input_array, int n, int flag){

    timer t;
    int sum=0;
    bool isSorted;

    if(flag==0)
    {//BST sort
        bs_tree bs;
        t.start();
        bs.insert(input_array, n);
        t.stop();
        cout << "  Time: " << t;
        sum = sum + t.real();
        isSorted = check_sorted(input_array, 0, bs.getArrayLength());
    }
    else
    {//RBT sort  
        rb_tree rb;
        t.start();
        rb.insert(input_array, n);
        t.stop();

        cout << "Total number of black nodes: " << rb.get_black_node_counts() << endl; 
        cout << "  Time: " << t;
        sum = sum + t.real();
        isSorted = check_sorted(input_array, 0, rb.getArrayLength());
    }
  
    //Check Whether Output Is Sorted
    if (isSorted)
      cout << "\tThe Output is sorted!" << endl;
    else
      cout << "ERROR: The output is not sorted!" << endl;

  return sum;
}
  
//Running Test Cases
void run_test_cases(int n)
{
  
  double sum_random = 0, 
         sum_sorted = 0, 
         avg_random = 0.00, 
         avg_sorted = 0.00, 
         sum_inverse_sorted = 0, 
         avg_inverse_sorted = 0;
  int flag; // 0 - for BST, 1 - for RBT

  for(int i=0; i<2; i++)
  {
    if(i==0)
    {
      cout << "Using Binary Search Tree Sort:------------------------ " << endl;
      flag = 0;
    }
    else
    {
      cout << "Using Red-Black Search Tree Sort:--------------------- " << endl;
      flag = 1;
    }

    for(int k = 0 ; k < 10 ; k++)
    {      
      cout << "\nFor random array: TestCase#" << k << " " ;
      int *a = create_random(n);
      sum_random += getSum(a, n, flag); 

      cout << "For sorted array: TestCase#" << k ;
      int *a1 = create_sorted(n);         
      sum_sorted += getSum(a1, n, flag);

      cout << "For inverse sorted array: TestCase#" << k ;
      int *a2 = create_reverse_sorted(n); 
      sum_inverse_sorted += getSum(a2, n, flag);

      cout << endl;
    }

    avg_random = sum_random / 10;
    avg_sorted = sum_sorted / 10;
    avg_inverse_sorted = sum_inverse_sorted / 10;

    cout << "\n----- Average Running Time -----" << " n = " << n << "-----\n" ;
    
    cout << "For Random Array : " << avg_random << "ms" << endl;
    cout << "For Sorted Array : " << avg_sorted << "ms" << endl;
    cout << "For Inverse Sorted Array : " << avg_inverse_sorted << "ms" << endl;
  }  
}



int main(int argc, char* argv[])
{ 
  //to run write "./hw4 n(size of array in positive integer)" without quotes
  run_test_cases(atoi(argv[1]));
  return 0;
}


