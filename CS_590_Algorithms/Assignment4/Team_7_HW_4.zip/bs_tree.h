#ifndef __BS_TREE_H__
#define __BS_TREE_H__

struct bs_tree_node 
{
  int		key;
  bs_tree_node*	left;
  bs_tree_node*	right;
  bs_tree_node*	p;
};

class bs_tree
{ 
  protected:
    bs_tree_node*	T_nil;
    bs_tree_node*	T_root;
    int counter = 0;
    int* array_of_keys;
    int new_array_length; 
    int height=0;

  public:
    bs_tree();
    ~bs_tree();

    void insert(int*, int);
    void insert(int);
    bs_tree_node* tree_search(bs_tree_node*, int);

    int inorder_output()
      { return inorder_output(T_root, 1); }
    void output()
      { output(T_root, 1); }  
   
    void setArrayOfkeys(int*& a)
      { array_of_keys = a; }  

    void setArrayLength(int n)
      { new_array_length = n; } 

    int getArrayLength()
    { return new_array_length; }

  protected:  	

    void insert(bs_tree_node*);

    void remove_all(bs_tree_node*);

    int inorder_output(bs_tree_node*, int);
    void output(bs_tree_node*, int);
};

#endif
