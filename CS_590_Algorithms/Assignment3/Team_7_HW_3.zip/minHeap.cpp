#include <iostream>
#include <climits>
#include "minHeap.h"

using namespace std; 

minHeap::minHeap(int cap) 
{ 
	heapArray = new int[cap];
	heapSize = 0;
	capacity = cap;
} 

minHeap::minHeap(){ }

void minHeap::insertKey(int k) 
{ 
	if(heapSize == capacity)
		cout << "Overflow error: Heap has reached its capacity!" << endl;
	else
	{
		heapSize++;
		int index = heapSize - 1;
		heapArray[index] = INT_MAX; //Using extreme positive integer value
		decreaseKey(index, k);
	}
} 

void minHeap::decreaseKey(int i, int new_val) 
{ 
	if(new_val > heapArray[i])
		cout << "Error: New key is already greater!" << endl;
	else
	{
		heapArray[i] = new_val;
		while(i != 0 && heapArray[parent(i)] > heapArray[i])
		{
			int temp = heapArray[i];
			heapArray[i] = heapArray[parent(i)];
			heapArray[parent(i)] = temp;
			i = parent(i);
		}
	}
} 

int minHeap::extractMin() 
{ 
	if(heapSize <= 0)
	{
		cout << "Underflow error: Heap is empty!" << endl;
		return -1;
	}
	else
	{
		int min = getMin();
		heapArray[0] = heapArray[heapSize-1];
		heapSize--;
		minHeapify(0);
        return min;
	}
} 

void minHeap::deleteKey(int i) 
{ 	
	decreaseKey(i, INT_MIN); //Using extreme negative integer value
    extractMin(); 
} 

void minHeap::minHeapify(int i) 
{ 
	int l = left(i), r = right(i);
	int smallest;

	if(l <= heapSize && heapArray[l] < heapArray[i])
		smallest = l;
	else
		smallest = i;

	if(r <= heapSize && heapArray[r] < heapArray[smallest])
		smallest = r;

	if(smallest != i)
	{
		int temp = heapArray[i];
		heapArray[i] = heapArray[smallest];
		heapArray[smallest] = temp;
		minHeapify(smallest);
	}
} 