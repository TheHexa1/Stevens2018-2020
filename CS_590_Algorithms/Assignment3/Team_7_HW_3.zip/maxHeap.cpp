#include <iostream>
#include <climits>
#include "maxHeap.h"

using namespace std; 



maxHeap::maxHeap(int cap) 
{ 
	heapSize = 0;
	capacity = cap;
	heapArray = new int[capacity];
} 

maxHeap::maxHeap(){ }

void maxHeap::insertKey(int k) 
{ 
	if(heapSize == capacity)
		cout << "Overflow error: Heap has reached its capacity!\n" << k << endl;
	else
	{
		heapSize++;
		int index = heapSize-1;
		heapArray[index] = INT_MIN;	//Using extreme negative integer value
		increaseKey(index,k);
	}
} 

void maxHeap::increaseKey(int i, int new_val) 
{ 
	if(new_val < heapArray[i])
		cout << "Error: New key is smaller than current key!" << endl;
	else
	{
		heapArray[i] = new_val;
		int p_index = parent(i);

		while(i != 0 && heapArray[p_index] < heapArray[i])
		{
			int temp = heapArray[p_index];
			heapArray[p_index] = heapArray[i];
			heapArray[i] = temp;
			i = p_index;
			p_index = parent(i);	
		}

	}
} 

int maxHeap::extractMax() 
{ 
	if(heapSize <= 0 )
	{
		cout << "Underflow error: Heap is empty!" << endl;
		return -1;
	}
	else
	{
		int max = getMax();
		heapArray[0] = heapArray[heapSize-1];
		heapSize--;
		maxHeapify(0);
		return max; 
	}

} 
 
void maxHeap::deleteKey(int i) 
{ 
	increaseKey(i,INT_MAX);	//Using extreme positive integer value
	extractMax();
} 

void maxHeap::maxHeapify(int i) 
{ 
	int l = left(i);
	int r = right(i);
	int largest;
	if( l <= heapSize && heapArray[l] > heapArray[i])
		largest = l;
	else
		largest = i;
	if(r <= heapSize && heapArray[r] > heapArray[largest])
		largest = r;
	if(largest != i)
	{
		int temp = heapArray[i];
		heapArray[i] = heapArray[largest];
		heapArray[largest] = temp;
		maxHeapify(largest);
	}
} 