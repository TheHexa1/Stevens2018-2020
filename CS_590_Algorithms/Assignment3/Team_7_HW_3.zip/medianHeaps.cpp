#include <iostream>
#include <climits>
#include "medianHeaps.h"
#include "minHeap.h"
#include "maxHeap.h"

using namespace std; 

//Initializing minHeap and maxHeap
medianHeaps::medianHeaps(int cap) 
{ 
	max_h = maxHeap(cap);	
    min_h = minHeap(cap);
    currentMedian = 0;
} 

//Destroying minHeap and maxHeap after code completion 
medianHeaps::~medianHeaps()
{
	delete min_h.getHeap();
	delete max_h.getHeap();
}

void medianHeaps::addNewNumber(int x) 
{ 	
	int size_diff = max_h.size() - min_h.size();

	if(size_diff > 0)
	{
		if(x < currentMedian)
		{
			min_h.insertKey(max_h.extractMax());
			max_h.insertKey(x);
		}
		else
		{
			min_h.insertKey(x);
		}

		currentMedian = getMedian();
	}
	else if( size_diff == 0)
	{
		if(x < currentMedian)
		{
			max_h.insertKey(x);
			currentMedian = getMedian();
		}
		else
		{
			min_h.insertKey(x);
			currentMedian = getMedian();
		}
	}
	else if( size_diff < 0)
	{
		if(x < currentMedian)
		{
			max_h.insertKey(x);
		}
		else
		{
			max_h.insertKey(min_h.extractMin());
			min_h.insertKey(x);
		}

		currentMedian = getMedian();
	}
} 

 
int medianHeaps::getMedian() 
{
	if(max_h.size() == min_h.size())		//Even number of elements
    	return (min_h.getMin() + max_h.getMax())/2; 
	else if( max_h.size() > min_h.size()) 	//MaxHeap contains more number of elements
		return max_h.getMax();
	else 									//MinHeap contains more number of elements
		return min_h.getMin();
} 
