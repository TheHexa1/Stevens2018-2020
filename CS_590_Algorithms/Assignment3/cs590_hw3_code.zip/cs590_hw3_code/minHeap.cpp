#include <iostream>
#include <climits>
#include "minHeap.h"

using namespace std; 


minHeap::minHeap(int cap) 
{ 

} 

void minHeap::insertKey(int k) 
{ 

} 

void minHeap::decreaseKey(int i, int new_val) 
{ 
	
} 

int minHeap::extractMin() 
{ 
	return 1;
} 

void minHeap::deleteKey(int i) 
{ 
 
} 

void minHeap::minHeapify(int i) 
{ 
	
} 