#include <iostream>
#include <climits>
#include "medianHeaps.h"
#include "minHeap.h"
#include "maxHeap.h"

using namespace std; 

medianHeaps::medianHeaps(int cap) 
{ 
	
} 

medianHeaps::~medianHeaps()
{

}

void medianHeaps::addNewNumber(int x) 
{ 

} 

 
int medianHeaps::getMedian() 
{
    return 0; 
} 
