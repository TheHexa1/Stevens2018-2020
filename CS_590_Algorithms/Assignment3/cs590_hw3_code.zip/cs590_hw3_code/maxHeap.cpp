#include <iostream>
#include <climits>
#include "maxHeap.h"

using namespace std; 



maxHeap::maxHeap(int cap) 
{ 

} 

void maxHeap::insertKey(int k) 
{ 
	
} 

void maxHeap::increaseKey(int i, int new_val) 
{ 
	
} 

int maxHeap::extractMax() 
{ 
	return 1; 
} 
 
void maxHeap::deleteKey(int i) 
{ 

} 

void maxHeap::maxHeapify(int i) 
{ 

} 