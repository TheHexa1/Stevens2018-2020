#ifndef __AM_GRAPH_H__
#define __AM_GRAPH_H__

#include <limits.h>
#include "random_generator.h"

struct vertex
{
  int d;
  int parent;
}; 
    
class graph
{
  protected:
    vertex* vertices;
    int**	m_edge;
    int		no_vert;


  public:
    graph(int);
    ~graph();

    int get_no_of_vertices()
      { return no_vert; }

    void output();
    void test();
    void init_single_source(int);
    void relax_edge(int, int, int);
    bool bellman_ford(int);
    bool random_graph(int,int,int);
    void floyd_warshall();
    int find_min(int,int);

  protected:
    void initialize();
    void permutation(int*, int);
};

#endif