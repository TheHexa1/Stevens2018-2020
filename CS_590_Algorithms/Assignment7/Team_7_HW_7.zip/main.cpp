#include <iostream>

#include "graph.h"
#include "random_generator.h"

using namespace std;

int main(int argc, char* argv[])
{ 
	int n = 5, m = 10, w =10;

	//Hard-coded test case
	// Due to the provided implementation of contructor; the graph will never be empty 
	// It will always have minumum 1 vertex
	graph g = graph(n);
	g.test();
	cout << "\n Testcase 1" << endl;
	g.output();
	g.bellman_ford(1); // 1 as Source vertex 
	g.floyd_warshall();

	//Test case using for random_graph() function
	graph g1 = graph(n);
	if(g1.random_graph(n,m,w))
	{
		cout << "\n Testcase 2" << endl;
		g1.output();
		g1.bellman_ford(2);
		g1.floyd_warshall();
	}
	return 0;
}
  
