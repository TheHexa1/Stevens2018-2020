
#include "graph.h"
#include <list>
#include <iostream>

using namespace std;

/*
 * constructor/destructor
 */
graph::graph(int n)
{ /*<<<*/
  no_vert = (n > 0) ? n : 1;
/*
 * allocate adjacency matrix
 */
  vertices = new vertex[no_vert];
  m_edge = new int*[no_vert];
  for (int i = 0; i < no_vert; i++)
    m_edge[i] = new int[no_vert];

  initialize();
} /*>>>*/

graph::~graph()
{ /*<<<*/ 
/*
 * delete nil element and all other allocated nodes
 */
  for (int i = 0; i < no_vert; i++)
    delete[] m_edge[i];
  delete[] m_edge;
  delete[] vertices;
} /*>>>*/


void graph::initialize()
{ /*<<<*/
/*
 * initialize adjacency matrix
 * -> use infinity to allow 0 weight edges
 */
  for (int i = 0; i < no_vert; i++)
    for (int j = 0; j < no_vert; j++)
        m_edge[i][j] = INT_MAX;

} /*>>>*/

void graph::permutation(int* perm, int n)
{ /*<<<*/
  random_generator rg;
  int p_tmp, p_pos;

  for (int i = 0; i < n; i++)
    perm[i] = i;
  
  for (int i = 0; i < n; i++)
  {
    rg >> p_pos;
    p_pos = (p_pos % (n - i)) + i;
    p_tmp = perm[i];
    perm[i] = perm[p_pos];
    perm[p_pos] = p_tmp;
  }
} /*>>>*/

void graph::output()
{ /*<<<*/
  cout << "[";
  for (int i = 0; i < no_vert; i++)
    {
      cout << "[\t";
      for (int j = 0; j < no_vert; j++)
	if (m_edge[i][j] == INT_MAX)
	  cout << "Inf\t";
	else
	  cout << m_edge[i][j] << "\t";
      cout << "]" << endl;
    }
  cout << "]" << endl;
} /*>>>*/

bool graph::random_graph(int n, int m, int w)
{
  //Input Checking
  if( n <= 0) //No. of vertices should not be negative
  {
    cout << "Please enter a valid positive number of vertices for random_graph() function" << endl;
    return false;
  }
  else if( m < 0) //No. of edges should be positive
  {
    cout << "Please enter a valid non negetive number of edges for random_graph() function" << endl;
    return false;
  }
  else if(m > (n*(n-1))) //Maximum number of edges since we discard self loop edges
  {
    cout << "Please enter a valid number of edges in the limit of 0 to (n*n-1) for random_graph() function" << endl;
    return false;
  }
  else if( w == 0) //[-0,0] is illogical limit hence we are avoiding it
  {
    cout << "Weight cannot be provided as 0 \nPlease enter a valid weight for random_graph() function" << endl;
    return false;
  }
  else
  {
    random_generator rg;
    int w1;
    int* perm = new int[n];

    //Assigning all edges
    while(m > 0)
    {
      permutation(perm,n); //Generating random paths
      for(int j=0; j < n-1 ; j++)
      {
        rg >> w1;
        w1 = w1 % w; //Limiting the weights
        if(w1%2 == 0) // Assigning -ve weights
          w1 = -w1;
        if(m>0)
        {
          if(m_edge[perm[j]][perm[j+1]] == INT_MAX)
          {
            m_edge[perm[j]][perm[j+1]] = w1; //Assigning edge
            m--;
          }
        }
      }
    }
    delete[] perm;
    return true;
  }
}

void graph::test()
{
  //Test-1 Pdf's example For flyod_warshall 
  m_edge[0][1] = 3;
  m_edge[0][4] = -4;
  m_edge[1][3] = 1;
  m_edge[1][4] = 7;
  m_edge[2][1] = 4;
  m_edge[0][2] = 8;
  m_edge[3][2] = -5;
  m_edge[4][3] = 6;
  m_edge[3][0] = 2;
}

void graph::init_single_source(int s)
{
  for(int i=0; i< no_vert; i++)
  {
    vertices[i].d = INT_MAX;
    vertices[i].parent = INT_MIN;
  }
  vertices[s].d = 0;
}

void graph::relax_edge(int u, int v, int w)
{
  if(vertices[u].d != INT_MAX && vertices[v].d > (vertices[u].d + w))
  {
    vertices[v].d = vertices[u].d + w;
    vertices[v].parent = vertices[u].d;
  }
}

bool graph::bellman_ford(int s)
{
  if( s < 0 || s >= no_vert)
  {
    cout << "Please enter a valid source vertex for bellman_ford() function" << endl;
    return false;
  }
  else
  {
    //Initializing
    init_single_source(s);
    
    //To iterate on all edges for all vertices in the adjacency matrix
    for(int k=0; k<no_vert; k++)
      for(int i=0; i<no_vert; i++)
        for(int j=0; j<no_vert; j++)
          if(m_edge[i][j] != INT_MAX)
            relax_edge(i,j,m_edge[i][j]); //Relax the edge

    // Test for -ve weight cycles
    for(int i=0; i<no_vert; i++)
      for(int j=0; j<no_vert; j++)
        if((vertices[j].d > (vertices[i].d + m_edge[i][j])) && m_edge[i][j] != INT_MAX) 
        {
          cout << "Negative Weight Cycle exists! "<< endl;
          return false;
        }

    cout << "Negative Weight Cycle does not exists"<< endl;
    return true;
  }
}


int graph::find_min(int t1, int t2)
{
  if(t1 == INT_MAX && t2 == INT_MAX)
  {
    return INT_MAX;
  }
  else if(t1 == INT_MAX)
  {
    return t2;
  }
  else
  {
    if(t1 < t2)
      return t1;
    else
      return t2;
  }
}

void graph::floyd_warshall()
{
  int min,t2,count=0,pos=0;
  
  //Only two D and two pi matrices needed
  int d[2][no_vert][no_vert]; 
  int pi[2][no_vert][no_vert];
  cout << "\n----------------Final Distance Matrix (D matrix)---------------------" << endl;

  //Iterating 3 for loops
  for(int k = 0; k <= no_vert ; k++)
  {
    for (int i = 0; i < no_vert; i++)
    {
      if(k == no_vert) //For printing
        cout << "[\t";
      for (int j = 0; j < no_vert; j++)
      {
        if(k == 0) //Initializing Weight matrix 
        {
          d[pos][i][j] = m_edge[i][j];
          pi[pos][i][j] = i;
          if(i == j || d[pos][i][j] == INT_MAX )
            pi[pos][i][j] = -1;
        }
        else
        {   
          if(i == j) //Discarding self-loops
          {
            d[count][i][j] = 0;
            pi[count][i][j] = -1;
          }
          else
          {
            if(d[pos-1][i][k-1] == INT_MAX || d[pos-1][k-1][j] == INT_MAX)
              t2 = INT_MAX;  
            else
              t2 = d[pos-1][i][k-1] + d[pos-1][k-1][j];
            
            min = find_min(d[pos-1][i][j],t2); //Using minimum using find_min()
            d[count][i][j] = min;
            pi[count][i][j] = pi[pos-1][i][j];
            if(min != INT_MAX)
              if(min != d[pos-1][i][j])
                pi[count][i][j] = pi[pos-1][k-1][j];
          }

          if(k == no_vert) //For printing
          {
            if(d[count][i][j] != INT_MAX)
              cout << d[count][i][j] << "\t";
            else
              cout << "Inf\t";
          }
        }         
      }

      if(k == no_vert) //For printing
        cout << "]" << endl;
    }

    //For keep tracking positions of 2 intermediates matrices
    if(count == 1)
    {
      count = 0;
      pos = 2;
    }
    else
    {
      count = 1;
      pos = 1;
    }
  }

  //Printing Pi Matrix
  cout << "\n---------------- Final Predecessor Matrix (Pi matrix)---------------------" << endl;
  
  //Position for final Pi matrix
  int k;
  if(no_vert % 2 == 0)
    k = 0;
  else
    k = 1;

  for (int i = 0; i < no_vert; i++)
  {
    cout << "[\t";
    for (int j = 0; j < no_vert; j++)
    {
      if (pi[k][i][j] == -1)
        cout << "nil\t";
      else
        cout << pi[k][i][j] << "\t";
    }
    cout << "]" << endl;
  }
}