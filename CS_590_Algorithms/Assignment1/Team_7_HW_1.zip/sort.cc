#include <cstdio>
#include <cstdlib>
#include <sort.h>
#include <iostream>
#include <timer.h>
#include <random_generator.h>

using namespace std;
timer t;

int ivector_length(int* v, int n)
{
  int sum;

  sum = 0;
  for (int i = 0; i < n; i++)
    sum += (v[i] < 0) ? -v[i] : v[i];

  return sum;
}

/*
 * naive insertion sort
 */
void insertion_sort(int** A, int n, int l, int r)
{ 
  register int i;
  int* key;

  for (int j = l+1; j <= r; j++)
    {
      key = A[j];
      i = j - 1;

      while ((i >= l) && (ivector_length(A[i], n) > ivector_length(key, n)))
        {
	  A[i+1] = A[i];
	  i = i - 1;
	}

      A[i+1] = key;
    }
}

//Improved Insertion Sort Implementation
void insertion_sort_im(int** A, int n, int l, int r)
{
  int temp[r+1];
  register int i;
  int *key, temp_key;

  for(int k=0 ; k<r+1 ; k++)
  {
    temp[k] = ivector_length(A[k],n);
  }
  for (int j = l+1; j <= r ; j++)
  {
    key = A[j];
    temp_key = temp[j];
    i = j - 1;
    while ((i >= l) && ( temp[i] > temp_key))
      {
        A[i+1] = A[i];
        temp[i+1] = temp[i];
        i = i - 1;
      }
    A[i+1] = key;
    temp[i+1] = temp_key;
  }  
}

//Merge Sort implementation
void merge_sort(int** A, int n, int p, int r)
{
  int q;

  if(p < r)
  {
    q = (p+r)/2;
    merge_sort(A,n,p,q);
    merge_sort(A,n,q+1,r);
    merge(A,n,p,q,r);
  } 
}

//Merge Function implementation for merge sort
void merge(int** A,int n,int p, int q,int r)
{
  int n1,n2;
  n1 = q-p+1;
  n2 = r-q;
  int *L[n1+1], *R[n2+1];
  int Ltemp[n1+1], Rtemp[n2+1];

  for(int i=0;i<n1;i++)
  {
	  L[i] = A[p+i];
	  Ltemp[i] = ivector_length(A[p+i],n);
  }

  for(int i=0;i<n2;i++)
  {
    R[i] = A[q+i+1];
    Rtemp[i] = ivector_length(A[q+i+1],n);
  }

  int i=0,j=0;
  int k = p;

  while (i < n1 && j < n2)
  {
    if(Ltemp[i] <= Rtemp[j]) 
    {
      A[k] = L[i];
      i++;
    }
    else
    {
      A[k] = R[j];
      j++;
    }
    k++;
  }

  while (i < n1)
  {
    A[k] = L[i];
    i++;
    k++;
  }

  while (j < n2)
  {
    A[k] = R[j];
    j++;
    k++;
  }

}
/*
 * Simple function to check that our sorting algorithm did work
 * -> problem, if we find position, where the (i-1)-th element is 
 *    greater than the i-th element.
 */
bool check_sorted(int** A, int n, int l, int r)
{
  for (int i = l+1; i <= r; i++)
    if (ivector_length(A[i-1], n) > ivector_length(A[i], n))
      return false;
  return true;
}


/*
 * generate sorted/reverse/random arrays of type hw1type
 */
int** create_ivector(int n, int m)
{
  int** iv_array;

  iv_array = new int*[m];
  for (int i = 0; i < m; i++)
    iv_array[i] = new int[n];

  return iv_array;
}

void remove_ivector(int** iv_array, int m)
{
  for (int i = 0; i < m; i++)
    delete[] iv_array[i];
  delete[] iv_array;
}

int** create_sorted_ivector(int n, int m)
{
  int** iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      iv_array[i][j] = (i+j)/n;

  return iv_array;
}

int** create_reverse_sorted_ivector(int n, int m)
{
  int** iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      iv_array[i][j] = ((m-i)+j)/n;

  return iv_array;
}

int** create_random_ivector(int n, int m, bool small)
{
  random_generator rg;
  int** iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      {
	rg >> iv_array[i][j];
	if (small)
	  iv_array[i][j] %= 100;
	else
	  iv_array[i][j] %= 65536;
      }

  return iv_array;
}

//Running Test Cases
void run_test_cases(int d,int m,int n)
{
  int** input_array;
  double sum_random , sum_sorted;
  double avg_random , avg_sorted;
  
  // For Random and Sorted vector arrays
  if( d == 0 || d == 1)   
  {
    int c = 1;

      while(c < 4)
      {
        sum_random = 0 , sum_sorted = 0, avg_random = 0.00, avg_sorted = 0.00;

        //for Naive Algorithm c=1
        if( c == 1)   
        {
          cout << "\n------Running Naive insertion sort algorithm for m = " << m << " n = " << n << "------\n" << endl;
          for(int k =0 ; k < 10 ; k++)
          {      
            input_array = create_random_ivector(n, m, true);
            cout << "\nFor Random Vector Array: " ;
            t.start();
            insertion_sort(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_random = sum_random + t.real();
          
            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            cout << "For Sorted Vector Array: " ;
            t.start();
            insertion_sort(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_sorted = sum_sorted + t.real();
         
            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            //Removing Old Vector Array So that We can Assign new Vector Array For Next Test Case
            remove_ivector(input_array,m);
          }

          avg_random = sum_random / 10;
          avg_sorted = sum_sorted / 10;
          cout << "\n------Average Running Time Of Naive Insertion Sort Algorithm for m = " << m << " n = " << n << "------\n" ;
          cout << "For Random Vector Array : " << avg_random << "ms" << endl;
          cout << "For Sorted Vector Array : " << avg_sorted << "ms" << endl;
        }
        //Improved Insertion Sort Algorithm Chosen
        else if( c == 2)    
        {
          cout << "\n------Running Improved Insertion Sort Algorithm for m = " << m << " n = " << n << "------\n" << endl;

          for(int k =0 ; k < 10 ; k++)
          {      
            input_array = create_random_ivector(n, m, true);
            cout << "\nFor Random Vector Array: " ;
            t.start();
            insertion_sort_im(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_random = sum_random + t.real();
         
            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            cout << "For Sorted Vector Array: " ;
            t.start();
            insertion_sort_im(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_sorted = sum_sorted + t.real();
         
            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            //Removing Old Vector Array So that We can Assign new Vector Array For Next Test Case
            remove_ivector(input_array,m);
          }

          avg_random = sum_random / 10;
          avg_sorted = sum_sorted / 10;
          cout << "\n------Average Running Time Of Improved Insertion Sort Algorithm for m = " << m << " n = " << n << "------\n" ;
          cout << "For Random Vector Array : " << avg_random << "ms" << endl;
          cout << "For Sorted Vector Array : " << avg_sorted << "ms" << endl;
        }  

        //Merge Sort Algorithm Chosen
        else    
        {
          cout << "\n------Running Merge sort algorithm for m = " << m << " n = " << n << "------\n" << endl;
          for(int k =0 ; k < 10 ; k++)
          {      
            input_array = create_random_ivector(n, m, true);
            cout << "\nFor Random Vector Array: " ;
            t.start();
            merge_sort(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_random = sum_random + t.real();
         
            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            cout << "For Sorted Vector Array: " ;
            t.start();
            merge_sort(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_sorted = sum_sorted + t.real();
         
            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            //Removing Old Vector Array So that We can Assign new Vector Array For Next Test Case
            remove_ivector(input_array,m);
          }

          avg_random = sum_random / 10;
          avg_sorted = sum_sorted / 10;
          cout << "\n------Average Running Time Of Merge Sort Algorithm for m = " << m << " n = " << n << "------\n" ;
          cout << "For Random Vector Array : " << avg_random << "ms" << endl;
          cout << "For Sorted Vector Array : " << avg_sorted << "ms" << endl;
        }
        c++;
      }
    }

    // For Reverse Sorted Array (d = -1)
    else
    {
      int c = 1;

      while( c < 4)
      {
        sum_random = sum_sorted = 0;
        avg_random = avg_sorted = 0.00;

        //Naive Algorithm Chosen
        if( c == 1)   
        {
        cout << "\n------Running Naive insertion sort algorithm for m = " << m << " n = " << n << "------\n" << endl;
          for(int k =0 ; k < 10 ; k++)
          {      
            input_array = create_reverse_sorted_ivector(n, m);
            cout << "For Reverse Sorted Vector Array: " ;
            t.start();
            insertion_sort(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_sorted = sum_sorted + t.real();  

            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            //Removing Old Vector Array So that We can Assign new Vector Array For Next Test Case
            remove_ivector(input_array,m);
          }

          avg_sorted = sum_sorted / 10;
          cout << "\n------Average Running Time Of Naive Insertion Sort Algorithm for m = " << m << " n = " << n << "------\n" ;
          cout << "For Reverse Sorted Vector Array : " << avg_sorted << "ms" << endl;
        }  

        //Improved Insertion Sort Algorithm Chosen
        else if( c == 2)    
        {
        cout << "\n------Running Improved insertion sort algorithm for m = " << m << " n = " << n << "------\n" << endl;
          for(int k =0 ; k < 10 ; k++)
          {      
            input_array = create_reverse_sorted_ivector(n, m);
            cout << "For Reverse Sorted Vector Array: " ;
            t.start();
            insertion_sort_im(input_array, n, 0, m-1);
            t.stop();
            cout << "Timer: " << t;
            sum_sorted = sum_sorted + t.real(); 

            //Check Whether Output Is Sorted
            if (check_sorted(input_array, n, 0, m-1))
              cout << "\tThe Output is sorted!" << endl;
            else
              cout << "ERROR: The output is not sorted!" << endl;

            //Removing Old Vector Array So that We can Assign new Vector Array For Next Test Case
            remove_ivector(input_array,m);
          }
          avg_sorted = sum_sorted / 10;
          cout << "\n------Average Running Time Of Improved Insertion Sort Algorithm for m = " << m << " n = " << n << "------\n" ;
          cout << "For Reverse Sorted Vector Array : " << avg_sorted << "ms" << endl;
        }  

        //Merge Sort Algorithm Chosen
        else 
          {
            cout << "\n------Running Merge sort algorithm for m = " << m << " n = " << n << "------\n" << endl;
            for(int k =0 ; k < 10 ; k++)
            {      
              input_array = create_reverse_sorted_ivector(n, m);
              cout << "For Reverse Sorted Vector Array: " ;
              t.start();
              merge_sort(input_array, n, 0, m-1);
              t.stop();
              cout << "Timer: " << t;
              sum_sorted = sum_sorted + t.real();  
              
              //Check Whether Output Is Sorted
              if (check_sorted(input_array, n, 0, m-1))
                cout << "\tThe Output is sorted!" << endl;
              else
                cout << "ERROR: The output is not sorted!" << endl;

              //Removing Old Vector Array So that We can Assign new Vector Array For Next Test Case
              remove_ivector(input_array,m);
            }

            avg_sorted = sum_sorted / 10;
            cout << "\n------Average Running Time Of Merge Sort Algorithm for m = " << m << " n = " << n << "------\n" ;
            cout << "For Reverse Sorted Vector Array : " << avg_sorted << "ms" << endl;
          }          
          c++;
        }
    }
}