#include <cstdio>
#include <cstdlib>
#include <sort.h>
#include <timer.h>
#include <random_generator.h>

int main(int argc, char* argv[])
{
    random_generator rg;
    timer t;
    int n, m, d, a;
    int choice = 1;
    int** input_array;

    
    while (choice == 1)
    {       
      cout << "Enter size of the random integer vector array(m) : " ;
      cin >> m;
      if(m < 0)
      {
        cout << "m cannot be negative" << endl;
        break;
      }
      cout << "Enter dimension of integer vector array(n) : ";
      cin >> n;
      cout << endl;
      if(n < 0)
      {
        cout << "n cannot be negative" << endl;
        break;
      }
      // run 20 test cases (10 for RANDOM and 10 for Sorted Vector Array)
      run_test_cases(0,m,n); 

      // run 10 test cases for reverse sorted array
      run_test_cases(-1,m,n); 

      cout << " \n \tContinue Testing ? (Enter '1' for 'Yes' and '0' for 'No') : " ;
      cin >> choice ;
    }   
    
    cout << "----------- Exiting PROGRAM ------------" << endl;
    
    return 0;
}

