#include "graph.h"

int main()
{
	//Testcases

	//Graph-1
	//Number of nodes for first graph
	int n1 = 6;

	//Creating matrix	
	int **a = new int*[n1];
	for(int i =0 ; i<n1 ; i++)
		a[i] = new int[n1];
	for(int i = 0; i<n1 ; i++)
		for(int j=0 ; j<n1 ; j++)
			a[i][j] = 0;

	//Setting value 1 for the purpose of assigning edges
	a[0][3] = 1;
	a[0][1] = 1;
	a[1][4] = 1;
	a[2][4] = 1;
	a[2][5] = 1;
	a[3][1] = 1;
	a[4][3] = 1;
	a[5][5] = 1;

	//Creating graph from already provided matrix
	Graph graph1 = Graph(a,n1);

	//Calling bfs and dfs algorithm for checking purpose
	graph1.bfs(0);
	graph1.dfs(0);


	//Graph-2
	//Number of nodes
	int n = 12;
	//Creating an empty graph from providing number of nodes
	Graph graph = Graph(n);

	//Assigning edges using set edge function
	graph.set_edge(0,3,1);
	graph.set_edge(3,0,1);
	graph.set_edge(1,3,1);
	graph.set_edge(3,1,1);
	graph.set_edge(1,2,1);
	graph.set_edge(3,4,1);
	graph.set_edge(4,3,1);
	graph.set_edge(4,2,1);
	graph.set_edge(4,6,1);
	graph.set_edge(6,7,1);
	graph.set_edge(7,8,1);
	graph.set_edge(7,5,1);
	graph.set_edge(5,8,1);
	graph.set_edge(8,5,1);
	graph.set_edge(7,10,1);
	graph.set_edge(10,6,1);
	graph.set_edge(10,9,1);
	graph.set_edge(9,11,1);
	graph.set_edge(11,10,1);

	cout << "\nAfter assigning edges to graph" << endl;
	graph.printGraph();

	//Calling bfs and dfs algorithm for checking purpose
	graph.bfs(0);
	graph.dfs(0);
    return 0;
}
