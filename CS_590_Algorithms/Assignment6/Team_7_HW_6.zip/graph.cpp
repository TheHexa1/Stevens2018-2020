#include "graph.h"

//Initializing a global iterator for print and bfs functions
set<int>::iterator itr;

void Graph::printGraph()
{
	//Iterating through each vertex's adjacency list
	for(int i=0 ; i< nodes ; i++)
	{
		//The term "start" denotes starting of the list
        cout << "Vertex("<< i << ") : start";
        for(itr = adjlist[i].begin(); itr!=adjlist[i].end();itr++)
        {
        	cout <<"->"<< *itr;
        }
        cout << endl;
	}
}

Graph::Graph(int n)
{
	//Assigning values
	nodes = n;

	//Initializing adjacency matrix
	matrix = new int*[n];
	for(int i=0 ; i < n ; i++)
		matrix[i] = new int[n];

	for(int i=0; i < n ; i++)
		for(int j =0 ; j < n; j++)
			matrix[i][j] = 0;

	//Initializing adjacency list for each vertex
	adjlist = new set<int>[n];

	//Printing graph
	cout << "\nAn empty Graph with " << nodes << " vertices successfuly created" << endl;
	printGraph();
}

Graph::Graph(int** a, int n)
{
		//Assigning the values
		nodes = n;
		matrix = a;
		
		//Initializing adjacency list for each vertex
		adjlist = new set<int>[n];
		
		//Assignning edges corrsponding to given matrix
		for(int i=0; i < n ; i++)
			for(int j =0 ; j < n; j++)
				if(matrix[i][j] == 1)
					set_edge(i,j,1);
		
		//Printing the graph
		cout << "\nGraph with " << nodes << " vertices successfuly created" << endl;
		printGraph();
}

bool Graph::set_edge(int u, int v, int val)
{

	if(val >= 1)
	{
		//val = 1 means we have to set the edge between the given 2 nodes
		matrix[u][v] = val;
		adjlist[u].insert(v);
		return true;
	}
	else if(val == 0)
	{
		//val = 0 means we have to delete the edge between the given 2 nodes provided that edge exist
		matrix[u][v] = val;
		if(adjlist[u].find(v) != adjlist[u].end())
			adjlist[u].erase(v);
		return true;
	}
	else
	{
		//The edge cannot be assign or deleted hence return false
		return false;
	}
}

void Graph::bfs(int s)
{
	//Basic error checking
	if(s >= nodes)
		cout << "\nError : Please give a valid source vertex" << endl;
	else
	{
		cout << "\nBFS order from source vertex as " << s << endl;

		//Initializing visited list
		visited = new set<int>;

		//Initial call
		bfs(s,visited);
	}
}

void Graph::bfs(int s, set<int>* visited)
{
	//Initially source vertex is always unvisited
	if(visited->empty())
		visited->insert(s);

	//Source vertex explored first
	cout << s << " ";

	//Initializing Queue
	queue<int> Q;

	//Push the source vertex for the exploration
	Q.push(s);

	//Algorithm
	int u;
	while(!Q.empty())
	{
		u = Q.front();

		//Pop the vertex from the queue for the exploration
		Q.pop();

		//Explore the vertex using its adjacency list
        for(itr = adjlist[u].begin(); itr!=adjlist[u].end();itr++)
        {
        	if(visited->find(*itr) == visited->end())
        	{
        		//Unvisited neighbor found hence push it to queue
        		visited->insert(*itr);
        		Q.push(*itr);

        		//Print the vertex as its encountered during exploration
        		cout << *itr << " ";	
        	}
        }
	}
	//Deleting Visited List from memory
	delete visited;
}

void Graph::dfs(int s)
{
	//Basic error checking
	if(s >= nodes)
		cout << "\nError : Please give a valid source vertex" << endl;
	else
	{
		cout << "\nDFS order from source vertex as " << s << endl;
		int j=0;

		//Initializing visited list
		visited = new set<int>;

		//Covering all vertices
		while(j < nodes)
		{
			if(visited->empty())
			{
				//Initial call
				dfs(s,visited);
			}
			else if((visited->find(j) == visited->end()) && s != j)
			{
				//For remaining unexplored vertex
				dfs(j,visited);
			}
			else
			{
				//For reaching terminating condition
				j++;
			}	
		}
		//Deleting Visited List from memory
		delete visited;
		cout << endl;
	}
}

void Graph::dfs(int s , set<int>* visited)
{
	//Add vertex as visited when encountered first
	visited->insert(s);

	//Have to create new iterator for each neighbor due to recursive calls of dfs function
	set<int>::iterator itr1;

	//Explore the vertex using its adjacency list
 	for(itr1 = adjlist[s].begin(); itr1!=adjlist[s].end();itr1++)
    {
    	if(visited->find(*itr1) == visited->end())
    	{
    		//Unvisited neighbor found hence explore them
    		dfs(*itr1,visited);
    	}
    }

    //Printing the vertex after finishing exploration of all of its neighbour
    cout << s << " ";
}

Graph::~Graph()
{
 		//Deleting Adjacency List from memory
		delete[] adjlist;

		//Deleting Adjacency Matrix from memory
		for (int i = 0; i < nodes; i++)
		{
			delete[] matrix[i];
		}
		delete[] matrix;
}